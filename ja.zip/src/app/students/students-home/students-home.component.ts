import { Component } from '@angular/core';



@Component({
    templateUrl: 'students-home.component.html',
    styleUrls: ['students-home.component.css'],
    standalone: false
})
export class StudentsHomeComponent {

  constructor() {
    // nada
  }

}
