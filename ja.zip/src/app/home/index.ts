/**
 * This barrel file provides the export for the lazy loaded BecasHomeComponent.
 */
export * from './home.component';

