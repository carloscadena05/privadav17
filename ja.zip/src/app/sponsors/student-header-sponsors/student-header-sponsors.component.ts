import { Component } from '@angular/core';
@Component({
    selector: 'app-student-header-sponsors',
    templateUrl: './student-header-sponsors.component.html',
    standalone: false
})
export class StudentHeaderSponsorsComponent {
  constructor() {
    console.log('hi from student-header-sponsors constructor');
  }
}
