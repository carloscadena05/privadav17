import { Component } from '@angular/core';

@Component({
    templateUrl: './sponsors.component.html',
    standalone: false
})
export class SponsorsComponent {

  constructor() {
    console.log('SponsorsComponent');
  }

}
