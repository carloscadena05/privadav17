import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-admins-member-search',
    templateUrl: './admins-member-search.component.html',
    styleUrls: ['./admins-member-search.component.css'],
    standalone: false
})
export class AdminsMemberSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
