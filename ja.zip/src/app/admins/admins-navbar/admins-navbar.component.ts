import { Component } from '@angular/core';

@Component({
    selector: 'app-admins-navbar',
    templateUrl: 'admins-navbar.component.html',
    styleUrls: ['admins-navbar.component.css'],
    standalone: false
})
export class AdminsNavbarComponent {
  constructor() {}
}
