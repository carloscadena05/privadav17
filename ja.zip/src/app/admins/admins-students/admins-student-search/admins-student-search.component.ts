import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-admins-student-search',
    templateUrl: './admins-student-search.component.html',
    styleUrls: ['./admins-student-search.component.css'],
    standalone: false
})
export class AdminsStudentSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
