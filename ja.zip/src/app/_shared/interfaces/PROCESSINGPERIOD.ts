export interface PROCESSINGPERIOD {
  id: string;
  descriptor: string;
}