export interface SORTCRITERIA {
  sortColumn: string;
  sortDirection: string;
}
