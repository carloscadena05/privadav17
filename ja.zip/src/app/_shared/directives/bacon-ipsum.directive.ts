import { Directive } from '@angular/core';

@Directive({selector: '[onlyMyBacon]'})
export class OnlyMyBacon {
  // not much going on here as well...
}