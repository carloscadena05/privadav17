export class SponsorGroupMember {

  constructor(
    public sponsorGroupMemberId?: number,
    public sponsorGroupId?: number
  ) { }
}
