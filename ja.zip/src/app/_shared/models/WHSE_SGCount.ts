export class WHSE_SGCount {

  constructor(
    public yearJoinedJA: number,
    public male: number,
    public female: number
  ) { }
}
