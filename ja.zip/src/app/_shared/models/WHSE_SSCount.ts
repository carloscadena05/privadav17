export class WHSE_SSCount {

  constructor(
    public yearJoinedJA: number,
    public current: number,
    public grad: number,
    public sabbatical: number,
    public pending: number,
    public dropped: number,
  ) { }
}
