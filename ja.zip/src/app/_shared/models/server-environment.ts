export class ServerEnvironment {

  constructor(
    public webApiServerName: string,
    public databaseServerName: string,
    public databaseName: string
  ) { }
}
