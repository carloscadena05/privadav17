export class SponsorGroupMemberDTO {

  constructor(
    public sponsorGroupMemberId?: number,
    public sponsorGroupMemberName?: string,
    public sponsorGroupId?: number,
    public sponsorGroupName?: string
  ) { }
}
