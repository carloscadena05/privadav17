export class SponsorGroup {

  constructor(
    public sponsorGroupId?: number,
    public sponsorGroupName?: string
  ) { }
}
