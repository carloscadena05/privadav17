export class WHSE_SGCount {

  constructor(

  ) { }
}
