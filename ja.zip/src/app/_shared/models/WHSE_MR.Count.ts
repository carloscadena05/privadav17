export class WHSE_MRCount {

  constructor(
    public yearMonth: string,
    public problems: number,
    public allGood: number,
    public celebrate: number,
    public concerned: number,
  ) { }
}
