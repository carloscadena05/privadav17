export class WHSE_SSRCount {

  constructor(
    public yearPeriod: string,
    public ssrCount: number
  ) { }
}
