export class WHSE_DailyMRCount {

  constructor(

    public formattedDate: string,
    public submittedDate: string,
    public submitted: number,
    public cumulative: number
    // public yearMonth: string,
    // public dayOfMonth: number,
    // public submitted: number,
    // public cumulative: number,
    // public totalStudents: number

  ) { }
}
