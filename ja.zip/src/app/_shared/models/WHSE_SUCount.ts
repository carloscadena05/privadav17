export class WHSE_SUCount {

  constructor(
    public universityAbbrev: number,
    public universigyName: number,
    public numberStudents : number,
  ) { }
}
