import { Component } from '@angular/core';
@Component({
    selector: 'app-student-header-mentors',
    templateUrl: './student-header-mentors.component.html',
    standalone: false
})
export class StudentHeaderMentorsComponent {
  constructor() {
    console.log('hi from student-header-mentors constructor');
  }
}
