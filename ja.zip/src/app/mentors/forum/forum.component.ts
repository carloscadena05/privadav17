import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-forum',
    templateUrl: './forum.component.html',
    styleUrls: ['./forum.component.css'],
    standalone: false
})
export class ForumComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
