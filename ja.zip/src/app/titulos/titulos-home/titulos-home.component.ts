import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-home',
    templateUrl: './titulos-home.component.html',
    standalone: false
})
export class TitulosHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
