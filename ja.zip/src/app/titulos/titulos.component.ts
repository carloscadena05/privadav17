import { Component } from '@angular/core';


/**
 * This class represents the lazy loaded AdminsComponent.
 */
@Component({
    templateUrl: 'titulos.component.html',
    standalone: false
})
export class TitulosComponent { }
