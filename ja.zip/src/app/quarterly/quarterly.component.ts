import { Component } from '@angular/core';

/**
 * This class represents the lazy loaded MentorsComponent.
 */
@Component({
    templateUrl: './quarterly.component.html',
    standalone: false
})
export class QuarterlyComponent {
  constructor() {}
}
